/* MXNestSpirit — panneau. Le calcul tourne ici, dans Chrome. */
(function () {
  'use strict';

  var cs = new CSInterface();
  var $ = function (id) { return document.getElementById(id); };
  var parts = [], result = null, busy = false, session = '';

  function log(m) { var e = $('log'); e.textContent = m + '\n' + e.textContent; }
  function hint(m, cls) { var h = $('hint'); h.textContent = m; h.className = 'hint' + (cls ? ' ' + cls : ''); }
  function esc(s) { return String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"'); }
  function call(fn, args, cb) {
    var a = (args || []).map(function (v) { return '"' + esc(v) + '"'; }).join(',');
    cs.evalScript(fn + '(' + a + ')', function (r) { cb(String(r)); });
  }
  function lock(on) {
    busy = on;
    $('scan').disabled = on;
    $('diag').disabled = on;
    $('run').disabled = on || !parts.length;
    $('apply').disabled = on || !result;
    $('marks').disabled = on;
    $('msave').disabled = on;
  }

  function options() {
    var rot = $('rot').value;
    var o = {
      sheetWidth: parseFloat($('sheet').value) || 1350,
      gap: parseFloat($('gap').value) || 0,
      edgeMargin: parseFloat($('edge').value) || 0,
      resolution: parseFloat($('prec').value) || 1,
      angleStep: rot === '0' ? -1 : parseFloat(rot),
      candidates: 24,
      angleTries: 10,
      fillHoles: $('holes').checked,
      smallPx: 120000,      // seuil « petite pièce » : elle balaie toute la planche
      scanFine: 8,
      maxLength: 60000
    };
    o.xStep = o.resolution >= 1 ? 6 : 4;
    return o;
  }

  $('mode').addEventListener('change', function () {
    $('namesrow').style.display = this.value === 'spot' ? '' : 'none';
    if (this.value === 'color') hint('Sélectionne un contour de coupe dans Illustrator, puis Analyser.');
  });

  // ---------- analyse ----------
  $('scan').addEventListener('click', function () {
    lock(true);
    hint('Lecture du document…');
    call('mxnsScan', [$('mode').value, $('cutnames').value,
                      $('selonly').checked ? 'true' : 'false',
                      $('regroup').checked ? 'true' : 'false',
                      $('tight').checked ? 'true' : 'false'], function (txt) {
      var lines = txt.split('\n');
      if (lines[0].indexOf('ERR') === 0) { hint(lines[0].split('\t')[1], 'err'); lock(false); return; }
      var list = [], cur = null, stat = null;
      session = '';
      for (var i = 1; i < lines.length; i++) {
        var f = lines[i].split('\t');
        if (f[0] === 'SESSION') session = f[1];
        else if (f[0] === 'P') { cur = { id: f[1], name: f[2], src: f[3], union: f[4] === '1', rings: [] }; list.push(cur); }
        else if (f[0] === 'R' && cur) {
          var pts = f[1].split(' '), ring = [];
          for (var k = 0; k < pts.length; k++) {
            var xy = pts[k].split(',');
            ring.push([parseFloat(xy[0]), parseFloat(xy[1])]);
          }
          if (ring.length > 2) cur.rings.push(ring);
        } else if (f[0] === 'END') stat = f;
      }
      for (var j = list.length - 1; j >= 0; j--) if (!list[j].rings.length) list.splice(j, 1);
      parts = list;
      result = null;
      setResult(null);
      draw(null);
      if (!parts.length) hint('Aucune pièce trouvée — essaie « Que contient le fichier ? »', 'err');
      else hint(parts.length + ' pièces prêtes.');
      if (stat) log('Analyse : ' + stat[1] + ' pièces, ' + stat[2] + ' ignorés, ' + stat[3] + ' regroupés · ' +
                    stat[4] + ' masque, ' + stat[5] + ' silhouette, ' + stat[6] + ' boîte.');
      lock(false);
    });
  });

  $('diag').addEventListener('click', function () {
    lock(true);
    call('mxnsDiag', [], function (txt) {
      var lines = txt.split('\n'), out = [];
      for (var i = 0; i < lines.length; i++) {
        var f = lines[i].split('\t');
        if (f[0] === 'TOTAL') out.push(f[1] + ' tracés');
        if (f[0] === 'SPOT') out.push('ton direct : ' + f[1]);
        if (f[0] === 'COL') out.push(f[1] + ' × ' + f[2]);
      }
      log(out.join('\n'));
      hint('Contenu listé ci-dessous.');
      lock(false);
    });
  });

  // ---------- imbrication ----------
  $('run').addEventListener('click', function () {
    if (!parts.length || busy) return;
    lock(true);
    var opt = options();
    var tries = parseInt($('effort').value, 10) || 12;
    // plus on se donne d'essais, plus on fouille finement à chaque essai
    if (tries >= 100) { opt.angleTries = 14; opt.xStep = 3; opt.candidates = 30; }
    else if (tries >= 16) { opt.angleTries = 12; opt.xStep = 4; opt.candidates = 24; }
    else { opt.angleTries = 8; opt.xStep = 6; opt.candidates = 16; }
    var t0 = Date.now();
    var best = null, pairsMade = 0;

    function runList(list, done) {
      var orders = MXNest.orderings(list, tries), i = 0, b = null;
      (function step() {
        if (i >= orders.length) { done(b); return; }
        hint('Recherche ' + (i + 1) + '/' + orders.length + '…');
        var r = MXNest.nestOnce(list, orders[i], opt, null);
        if (r && (!b || r.failed.length < b.failed.length ||
                 (r.failed.length === b.failed.length && r.length < b.length))) {
          b = r;
          setResult(b);
          draw(b);
        }
        i++;
        setTimeout(step, 0);
      })();
    }

    runList(parts, function (plain) {
      best = plain;
      if (!$('pairs').checked || parts.length < 2 || parts.length > 60) return finish();
      hint('Essai d\'emboîtement par paires…');
      setTimeout(function () {
        try {
          var resP = MXNest.safeResolution(parts, opt);
          var pr = MXNest.buildPairs(parts, opt, resP, Math.round(opt.gap * resP), 24);
          if (!pr.made) return finish();
          runList(pr.parts, function (withPairs) {
            if (withPairs && best && withPairs.length < best.length - 0.5) { best = withPairs; pairsMade = pr.made; }
            finish();
          });
        } catch (e) { finish(); }
      }, 0);
    });

    function finish() {
      result = best;
      setResult(best);
      draw(best);
      var bad = -1;
      try { bad = MXNest.verify(best, opt); } catch (e) { }
      var s = ((Date.now() - t0) / 1000).toFixed(1);
      log('Imbrication : ' + best.placements.length + ' pièces, ' + (best.length / 1000).toFixed(3) + ' m, ' +
          (best.fill * 100).toFixed(1) + ' % en ' + s + ' s' +
          (pairsMade ? ' · ' + pairsMade + ' couple(s) retenus' : '') +
          (bad === 0 ? ' · aucun contact' : bad > 0 ? ' · ' + bad + ' CONTACT' : ''));
      hint(bad > 0 ? bad + ' pièce(s) en contact — préviens-moi.' : 'Terminé en ' + s + ' s.',
           bad > 0 ? 'warn' : null);
      lock(false);
    }
  });

  function setResult(r) {
    $('wid').textContent = (parseFloat($('sheet').value) || 1350) + ' mm';
    if (!r) {
      $('len').textContent = '—'; $('fill').textContent = '—'; $('waste').textContent = '—';
      $('result').className = 'result';
      return;
    }
    $('len').textContent = (r.length / 1000).toFixed(3).replace('.', ',');
    $('fill').textContent = (r.fill * 100).toFixed(1).replace('.', ',') + ' %';
    var surf = r.length * r.sheetWidth / 1e6;
    if (!r.sheetWidth) surf = r.length * (parseFloat($('sheet').value) || 1350) / 1e6;
    $('waste').textContent = (surf - r.partArea / 1e6).toFixed(2).replace('.', ',') + ' m²';
    $('result').className = 'result done';
  }

  // ---------- aperçu ----------
  var PAL = ['#ff5a1f', '#4aa3df', '#6ec07a', '#e8c14a', '#b07ad4', '#4fc3bd'];

  function draw(r) {
    var cv = $('preview'), ctx = cv.getContext('2d');
    var W = cv.clientWidth || 380;
    var sw = parseFloat($('sheet').value) || 1350;
    var len = r ? Math.max(r.length, 100) : sw * 0.5;
    var scale = W / sw;
    cv.width = W;
    cv.height = Math.max(80, Math.min(len * scale, 2000));
    ctx.fillStyle = '#1e1e1e';
    ctx.fillRect(0, 0, cv.width, cv.height);
    if (!r) return;
    for (var p = 0; p < r.placements.length; p++) {
      var P = r.placements[p], src = P.part;
      if (!src) continue;
      var rings = [];
      for (var k = 0; k < src.rings.length; k++) rings.push(MXNest.rotatePoly(src.rings[k], P.angle * Math.PI / 180));
      var bb = MXNest.bboxOf(rings);
      var dx = P.x - bb[0], dy = P.y - bb[1];
      ctx.beginPath();
      for (var i = 0; i < rings.length; i++) {
        for (var q = 0; q < rings[i].length; q++) {
          var X = (rings[i][q][0] + dx) * scale, Y = (rings[i][q][1] + dy) * scale;
          if (q === 0) ctx.moveTo(X, Y); else ctx.lineTo(X, Y);
        }
        ctx.closePath();
      }
      ctx.fillStyle = PAL[p % PAL.length];
      ctx.globalAlpha = 0.6;
      ctx.fill(src.union ? 'nonzero' : 'evenodd');
      ctx.globalAlpha = 1;
      ctx.strokeStyle = '#111';
      ctx.lineWidth = 1;
      ctx.stroke();
    }
  }

  // ---------- application ----------
  $('apply').addEventListener('click', function () {
    if (!result || busy) return;
    lock(true);
    hint('Application…');
    var rows = [];
    for (var i = 0; i < result.placements.length; i++) {
      var P = result.placements[i];
      rows.push(P.part.id + ',' + P.angle + ',' + P.x.toFixed(2) + ',' + P.y.toFixed(2));
    }
    call('mxnsApply', [rows.join(';'), String(parseFloat($('sheet').value) || 1350),
                       String(result.length), $('fitab').checked ? 'true' : 'false', session], function (txt) {
      var f = txt.split('\t');
      if (f[0] !== 'OK') hint(f[1] || txt, 'err');
      else {
        hint(f[1] + ' pièce(s) placées' + (f[2] > 0 ? ' — ' + f[2] + ' introuvable(s)' : '') + '. Ctrl+Z annule.');
        log('Appliqué : ' + f[1] + ' pièces sur ' + (result.length / 1000).toFixed(3) + ' m.');
      }
      lock(false);
    });
  });

  $('marks').addEventListener('click', function () {
    if (busy) return;
    lock(true);
    call('mxnsMarks', [$('markd').value, $('marki').value, 'Regmark', 'false',
                       $('mshape').value, $('markw').value], function (txt) {
      var f = txt.split('\t');
      if (f[0] !== 'OK') hint(f[1] || txt, 'err');
      else {
        hint(f[1] + ' repère(s) posé(s) sur le calque Regmark' +
             (f[2] > 0 ? ' — ATTENTION, ' + f[2] + ' repère(s) recouvert(s) par une pièce.' : '.'),
             f[2] > 0 ? 'warn' : null);
        log('Repères : ' + f[1] + ' posés, ' + f[2] + ' recouverts.');
      }
      lock(false);
    });
  });

  /* Presets machine. Seules deux valeurs sont documentées : les ronds de 10 mm
     relevés sur les planches de l'atelier, et les angles Graphtec (manuel
     CE7000 : taille 5 à 20 mm, trait 0,3 à 1,0 mm, ligne unique). Pour les
     autres machines, rien n'est deviné : tu règles une fois et tu mémorises. */
  var PRESETS = {
    valiani:  { shape: 'circle', size: 10, inset: 10, line: 1 },
    graphtec: { shape: 'corner', size: 20, inset: 15, line: 1 }
  };
  try {
    var saved = window.localStorage.getItem('mxns_presets');
    if (saved) {
      var extra = JSON.parse(saved);
      for (var kk in extra) if (extra.hasOwnProperty(kk)) PRESETS[kk] = extra[kk];
    }
  } catch (ePr) { }

  function loadPreset(name) {
    var p = PRESETS[name];
    if (!p) return;
    $('mshape').value = p.shape;
    $('markd').value = p.size;
    $('marki').value = p.inset;
    $('markw').value = p.line;
  }
  $('mpreset').addEventListener('change', function () { loadPreset(this.value); });
  loadPreset('valiani');

  $('msave').addEventListener('click', function () {
    var name = $('mpreset').value;
    PRESETS[name] = { shape: $('mshape').value, size: parseFloat($('markd').value),
                      inset: parseFloat($('marki').value), line: parseFloat($('markw').value) };
    try {
      window.localStorage.setItem('mxns_presets', JSON.stringify(PRESETS));
      hint('Réglage de repères mémorisé pour « ' + name + ' ».');
    } catch (eS) { hint('Mémorisation impossible sur cette installation.', 'warn'); }
  });

  window.addEventListener('resize', function () { draw(result); });
  call('mxnsPing', [], function (txt) {
    var f = txt.split('\t');
    $('hostinfo').textContent = f[0] === 'OK' ? f[1] + ' ' + String(f[2]).split(' ')[0] + ' · ' + f[3] : 'hôte indisponible';
  });
  draw(null);
  lock(false);
})();
