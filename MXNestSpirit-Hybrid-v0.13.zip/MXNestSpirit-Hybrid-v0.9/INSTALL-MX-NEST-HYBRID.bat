@echo off
cd /d "%~dp0spiritpanel"
call install-windows.bat
