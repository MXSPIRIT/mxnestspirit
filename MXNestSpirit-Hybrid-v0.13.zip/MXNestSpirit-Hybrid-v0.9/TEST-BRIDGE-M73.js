const fs=require('fs'), vm=require('vm');
const root=__dirname;
const bridgeCode=fs.readFileSync(root+'/spiritpanel/js/sparrow.js','utf8');
const sb={console}; vm.createContext(sb); vm.runInContext(bridgeCode+';globalThis.__SB=SparrowBridge;',sb);
const raw=JSON.parse(fs.readFileSync(root+'/fixtures/m73_parts_v10.json','utf8'));
const parts=raw.map(p=>({id:p.id,name:p.name,union:!!p.union,contours:p.rings}));
const b=sb.__SB.buildInstance(parts,{usableWidthMm:1350,spacingMm:0.5,simplifyEpsMm:0,forceHull:false,hullGroups:false,rotStepDeg:0});
if(b.instance.items.length!==parts.length) throw new Error('fixture conversion incomplete');
const placed=[]; let y=0;
for(const item of b.instance.items){
  const ring=item.shape.data; let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
  for(const q of ring){minX=Math.min(minX,q[0]);minY=Math.min(minY,q[1]);maxX=Math.max(maxX,q[0]);maxY=Math.max(maxY,q[1]);}
  placed.push({item_id:item.id,transformation:{rotation:0,translation:[-minX,-minY+y]}});
  y += maxY-minY+2;
}
const r=sb.__SB.readSolution({solution:{layout:{placed_items:placed}}},parts,b.meta);
if(r.placements.length!==parts.length || r.notPlacedCount || r.duplicatePlacements || r.maxErrorMm>0.05) throw new Error('bridge verification failed');
if(!(r.usedLengthMm>0)) throw new Error('bridge zero length');
console.log('PASS: '+r.placements.length+'/'+parts.length+' placements, '+r.usedLengthMm.toFixed(3)+' mm, maxError='+r.maxErrorMm);
